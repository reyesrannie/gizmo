export const totalAmount = (taxComputation) => {
  const total = (taxComputation?.result || []).reduce((acc, curr) => {
    return curr?.credit !== 0 ? acc + 0 : acc + parseFloat(curr?.amount || 0);
  }, 0);

  return total;
};

export const totalInputTax = (taxComputation) => {
  const total = (taxComputation?.result || []).reduce((acc, curr) => {
    return acc + parseFloat(curr?.vat_input_tax || 0);
  }, 0);

  return total;
};

export const totalWTax = (taxComputation) => {
  const total = (taxComputation?.result || []).reduce((acc, curr) => {
    return acc + parseFloat(curr?.wtax_payable_cr || 0);
  }, 0);

  return total;
};

export const totalAccount = (taxComputation) => {
  return (taxComputation?.result || []).reduce((acc, curr) => {
    const value = parseFloat(curr?.account || 0);
    return curr?.credit !== 0 ? acc - value : acc + value;
  }, 0);
};

export const totalAccountPaginated = (taxComputation) => {
  return (taxComputation?.result?.data || []).reduce((acc, curr) => {
    const value = parseFloat(curr?.account || 0);
    return curr?.credit !== 0 ? acc - value : acc + value;
  }, 0);
};

export const totalVat = (taxComputation, property) => {
  const total = taxComputation?.result?.data?.reduce((acc, curr) => {
    return curr?.credit !== 0 ? acc + 0 : acc + parseFloat(curr[property] || 0);
  }, 0);

  return total;
};

export const totalVatNonPaginate = (taxComputation, property) => {
  const total = taxComputation?.result?.reduce((acc, curr) => {
    return curr?.credit !== 0 ? acc + 0 : acc + parseFloat(curr[property] || 0);
  }, 0);

  return total;
};

export const totalCredit = (taxComputation, property) => {
  const total = taxComputation?.result?.data?.reduce((acc, curr) => {
    return acc + parseFloat(curr[property] || 0);
  }, 0);

  return total;
};

export const totalAccountMapping = (taxComputation, items) => {
  const getAllSameID = taxComputation?.result?.filter(
    (item) => items?.transactions?.id === item?.transaction_id
  );

  return (getAllSameID || []).reduce((acc, curr) => {
    const value = parseFloat(curr?.account ?? 0);
    return curr?.credit !== 0 ? acc - value : acc + value;
  }, 0);
};

export const totalAmountCheck = (item) => {
  const totalAmount = item?.reduce((acc, curr) => {
    const value = parseFloat(curr?.checkNo?.amount || 0);
    return curr?.checkNo?.state === "Cancelled" ? acc + 0 : acc + value;
  }, 0);

  return totalAmount;
};

export const totalAmountCheckForm = (item) => {
  const totalAmount = item?.reduce((acc, curr) => {
    return acc + parseFloat(curr?.amount || 0);
  }, 0);

  return totalAmount;
};

export const compute2307 = (data) => {
  const calculateAmount = (field) =>
    data?.reduce(
      (acc, curr) =>
        curr?.credit !== 0
          ? acc - parseFloat(curr[field] || 0)
          : acc + parseFloat(curr[field] || 0),
      0
    );

  const calculateWTax = (field) =>
    data?.reduce(
      (acc, curr) =>
        parseFloat(curr[field]) !== 0
          ? curr.credit === 0
            ? acc + parseFloat(curr.wtax_payable_cr || 0)
            : acc - parseFloat(curr.wtax_payable_cr || 0)
          : acc,
      0
    );

  return {
    vpl: calculateAmount("vat_local"),
    npl: calculateAmount("nvat_local"),
    vps: calculateAmount("vat_service"),
    nps: calculateAmount("nvat_service"),
    wTaxL: calculateWTax("vat_local"),
    wTaxS: calculateWTax("vat_service"),
    wNTaxL: calculateWTax("nvat_local"),
    wNTaxS: calculateWTax("nvat_service"),
  };
};
